

export class UsersData{
    constructor(public name:string="",public city:string,public email:string="",public password:string=""){

    }
}