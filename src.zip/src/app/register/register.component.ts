import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersData } from 'src/Model/UsersData';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  nusersData =new UsersData("Vishwa","Pune","vishwa@123gmail.com","me123");
  constructor(private usersData:UsersData,private router:Router) { }

  ngOnInit(): void {
  }

}
