import { Injectable } from '@angular/core';
import { UsersData } from 'src/Model/UsersData';

@Injectable({
  providedIn: 'root'
})
export class UsersDataService {

  usersData:UsersData[]=[];
  constructor() { }
}
