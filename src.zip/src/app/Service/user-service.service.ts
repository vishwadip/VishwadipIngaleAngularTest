import { Injectable } from '@angular/core';
import { User } from 'src/Model/User';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  users:User[]=[];
  constructor() {
    let u1=new User(101,"vishwa@gmail.com");
    let u2=new User(102,"Mahesh@gmail.com");
    let u3=new User(103,"Ramesh@gmail.com");
    let u4=new User(104,"Roma@gmail.com");
    let u5=new User(105,"leela@gmail.com");
     this.users.push(u1);
     this.users.push(u2);
     this.users.push(u3);
     this.users.push(u4);
     this.users.push(u5);
   }
  // checkUser(users:User):boolean{
  //   if(users.email===users && users.password==="zensar@123"){
  //     return true;
  //   }
  //   return false;
  }
}
